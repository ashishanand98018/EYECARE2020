package com.eyecare20_20.application;
import android.app.admin.DeviceAdminReceiver;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver { }
