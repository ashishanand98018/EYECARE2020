package com.eyecare20_20.application;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    private TextView tvStatus;
    private Button btnStart, btnStop, btnReset;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        tvStatus = v.findViewById(R.id.tvStatus);
        btnStart = v.findViewById(R.id.btnStart);
        btnStop = v.findViewById(R.id.btnStop);
        btnReset = v.findViewById(R.id.btnReset);

        SharedPreferences prefs = getActivity().getSharedPreferences("ec_prefs", 0);

        btnStart.setOnClickListener(view -> {
            Intent i = new Intent(getActivity(), TimerService.class);
            i.setAction("START");
            getActivity().startForegroundService(i);
            tvStatus.setText("Work Started");
        });

        btnStop.setOnClickListener(view -> {
            Intent i = new Intent(getActivity(), TimerService.class);
            i.setAction("STOP");
            getActivity().startService(i);
            tvStatus.setText("Stopped");
        });

        btnReset.setOnClickListener(view -> {
            Intent i = new Intent(getActivity(), TimerService.class);
            i.setAction("RESET");
            getActivity().startService(i);
            tvStatus.setText("Reset");
        });

        return v;
    }
}
