package com.eyecare20_20.application;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ScreenTimeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ScreenTimeFragment()).commit();
    }
}
