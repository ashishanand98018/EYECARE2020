package com.eyecare20_20.application;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.admin.DevicePolicyManager;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class TimerService extends Service {

    private CountDownTimer timer;
    private boolean isRunning = false;
    private ComponentName compName;
    private SharedPreferences prefs;
    private final String CHANNEL_ID = "ec_timer_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("ec_prefs", Context.MODE_PRIVATE);
        compName = new ComponentName(this, MyDeviceAdminReceiver.class);
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Timer Channel", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if ("START".equals(action)) startTimer();
            else if ("STOP".equals(action)) stopTimer();
            else if ("RESET".equals(action)) resetTimer();
        }
        return START_STICKY;
    }

    private void startTimer() {
        if (isRunning) return;
        int minutes = prefs.getInt("work_minutes", 20);
        long millis = minutes * 60 * 1000L;
        startForeground(1, buildNotification("Work in progress..."));
        timer = new CountDownTimer(millis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) { }
            @Override
            public void onFinish() {
                // Lock screen if enabled
                boolean lock = prefs.getBoolean("lock_screen", false);
                if (lock) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                    if (dpm.isAdminActive(compName)) {
                        dpm.lockNow();
                    }
                }
                // start break
                startBreak();
            }
        }.start();
        isRunning = true;
    }

    private void startBreak() {
        int secs = prefs.getInt("break_seconds", 20);
        long millis = secs * 1000L;
        timer = new CountDownTimer(millis, 1000) {
            @Override
            public void onTick(long l) { }
            @Override
            public void onFinish() {
                // resume work automatically
                startTimer();
            }
        }.start();
    }

    private void stopTimer() {
        if (timer != null) timer.cancel();
        stopForeground(true);
        isRunning = false;
    }

    private void resetTimer() {
        stopTimer();
        startTimer();
    }

    private Notification buildNotification(String text) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("EyeCare 20-20")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setOngoing(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
