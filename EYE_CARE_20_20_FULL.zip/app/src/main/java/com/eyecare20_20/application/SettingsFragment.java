package com.eyecare20_20.application;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    private EditText etWork, etBreak;
    private Switch switchLock;
    private Button btnSave;
    private ComponentName compName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_settings, container, false);
        etWork = v.findViewById(R.id.etWork);
        etBreak = v.findViewById(R.id.etBreak);
        switchLock = v.findViewById(R.id.switchLock);
        btnSave = v.findViewById(R.id.btnSave);

        compName = new ComponentName(getActivity(), MyDeviceAdminReceiver.class);

        SharedPreferences prefs = getActivity().getSharedPreferences("ec_prefs", Context.MODE_PRIVATE);
        etWork.setText(String.valueOf(prefs.getInt("work_minutes", 20)));
        etBreak.setText(String.valueOf(prefs.getInt("break_seconds", 20)));
        switchLock.setChecked(prefs.getBoolean("lock_screen", false));

        switchLock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow lock screen during breaks");
                startActivity(intent);
            }
        });

        btnSave.setOnClickListener(view -> {
            int w = Integer.parseInt(etWork.getText().toString());
            int b = Integer.parseInt(etBreak.getText().toString());
            prefs.edit().putInt("work_minutes", w).putInt("break_seconds", b).putBoolean("lock_screen", switchLock.isChecked()).apply();
        });

        return v;
    }
}
