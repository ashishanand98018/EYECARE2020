package com.eyecare20_20.application;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                Fragment selected = null;
                switch (item.getItemId()) {
                    case R.id.nav_home: selected = new HomeFragment(); break;
                    case R.id.nav_screen_time: selected = new ScreenTimeFragment(); break;
                    case R.id.nav_settings: selected = new SettingsFragment(); break;
                }
                if (selected != null) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selected).commit();
                }
                return true;
            }
        });

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        }
    }
}
