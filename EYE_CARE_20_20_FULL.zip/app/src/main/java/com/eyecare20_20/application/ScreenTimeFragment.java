package com.eyecare20_20.application;

import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class ScreenTimeFragment extends Fragment {

    private TextView tvTotal;
    private BarChart chart;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_screen_time, container, false);
        tvTotal = v.findViewById(R.id.tvTotal);
        chart = v.findViewById(R.id.chart);

        if (!hasUsageStatsPermission()) {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            tvTotal.setText("Grant Usage Access and reopen");
            return v;
        }

        long total = getTotalUsageForToday();
        long mins = total / 60000;
        tvTotal.setText("Total today: " + mins + " min");

        ArrayList<BarEntry> entries = new ArrayList<>();
        for (int i=0;i<7;i++){
            entries.add(new BarEntry(i, (float)(i+1)*10)); // placeholder
        }
        BarDataSet set = new BarDataSet(entries, "Minutes");
        BarData data = new BarData(set);
        chart.setData(data);
        chart.invalidate();

        return v;
    }

    private boolean hasUsageStatsPermission() {
        try {
            android.app.AppOpsManager appOps = (android.app.AppOpsManager) getActivity().getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), getActivity().getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private long getTotalUsageForToday() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0);
        long start = cal.getTimeInMillis();
        long end = System.currentTimeMillis();
        UsageStatsManager usm = (UsageStatsManager) getActivity().getSystemService(Context.USAGE_STATS_SERVICE);
        Map<String, android.app.usage.UsageStats> stats = usm.queryAndAggregateUsageStats(start, end);
        long total=0;
        for (Map.Entry<String, android.app.usage.UsageStats> e : stats.entrySet()){
            android.app.usage.UsageStats s = e.getValue();
            total += s.getTotalTimeVisible() + s.getTotalTimeForeground();
        }
        return total;
    }
}
