EYE CARE 20-20 FULL
-------------------
This is a full AndroidX starter project (Java) built to match the mind-map:
- Home fragment with Start/Stop/Reset (TimerService runs as foreground service)
- Screen Time fragment (UsageStats placeholder + MPAndroidChart)
- Settings fragment (work/break time, device admin toggle)
- DeviceAdminReceiver and device_admin_receiver.xml for lockNow()
- BootReceiver to restart service after device boot

How to build:
1. Open this project in Android Studio (recommended) or GitHub Codespaces with Android SDK installed.
2. Sync Gradle. You may need to update Gradle plugin if your environment differs.
3. Run on a real device (Usage Access and Device Admin require real device Settings).
